//
//  ViewController.swift
//  GMUTransit_Project_Fall23_TieuBryan
//
//  DISCLAIMER STATEMENT: "This App is developed as an educational project." If any copyrighted materials are included in accordance to the multimedia fair use guidelines, a notice should be added and states that "certain materials are included under the fair use exemption of the U.S. Copyright Law and have been prepared according to the multimedia fair use guidelines and are restricted from further use".
//
//  Created by Bryan Tieu on 10/10/23.
//

import UIKit

// Sound Code (Cannot hear the sound output from my computer since I am using MacInTheCloud).
import AVKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var lblAppTitle: UILabel!
    
    @IBOutlet weak var lblTransitName: UILabel!
    
    @IBOutlet weak var txtTransitDescription: UITextView!
    
    @IBOutlet weak var lblFrequency: UILabel!
    
    @IBOutlet weak var lblTransitFare: UILabel!
    
    @IBOutlet weak var lblWeekend: UILabel!
    
    @IBOutlet weak var lblFirstDeparture: UILabel!
    
    @IBOutlet weak var lblLastDeparture: UILabel!
    
    @IBOutlet weak var lblReliability: UILabel!
    
    @IBOutlet weak var imgTransitImage: UIImageView!
    
    @IBOutlet weak var imgLogoImage: UIImageView!
    
    @IBOutlet weak var scAreaOne: UIScrollView!
    
    @IBOutlet weak var swFavorite: UISwitch!
    
    @IBOutlet weak var lblDiffColor: UILabel!
    
    //var TransitRouteArray = ["CUE Green 1", "CUE Green 2", "CUE Gold 1", "CUE Gold 2", "Metrobus 29K", "Metrobus 17G"]
    var TransitRouteArray = [TransitRoute]()
    var randomTransit = TransitRoute()
    
    // Sound Code (Cannot hear the sound output from my computer since I am using MacInTheCloud).
    var mySoundFile: AVAudioPlayer!
    
    @IBAction func swFavoriteValChanged(_ sender: Any) {
        if (swFavorite.isOn) {
            UserDefaults.standard.set(lblTransitName.text, forKey: "favorite")
        }
        else {
            UserDefaults.standard.set("", forKey: "favorite")
        }
        
    }
    
    @IBAction func btnNextTransit(_ sender: Any) {
        setLabels()
        
    }
    
    @IBAction func btnWebSite(_ sender: Any) {
        let browserApp = UIApplication.shared
        let url = URL(string: randomTransit.TransitWebsite)
        browserApp.open(url!)
        
    }
    
    func setLabels() {
        randomTransit = TransitRouteArray.randomElement()!
        
        lblTransitName.text = randomTransit.TransitName
        txtTransitDescription.text = randomTransit.TransitDescription
        lblFrequency.text = randomTransit.TransitFrequency
        lblTransitFare.text = randomTransit.TransitFare
        lblWeekend.text = randomTransit.TransitWeekendService
        lblFirstDeparture.text = randomTransit.TransitFirstDeparture
        lblLastDeparture.text = randomTransit.TransitLastDeparture
        lblReliability.text = randomTransit.TransitReliability
        
        let favoriteRoute = UserDefaults.standard.string(forKey: "favorite")
        swFavorite.isOn = (randomTransit.TransitName == favoriteRoute)
        
        switch (randomTransit.TransitReliability) {
        case "Poor":
            lblDiffColor.backgroundColor = UIColor(red: 255/255, green: 38/255, blue: 0/255, alpha: 1)
        break
        case "OK":
            lblDiffColor.backgroundColor = UIColor(red: 255/255, green: 251/255, blue: 0/255, alpha: 1)
        break
        case "Good":
            lblDiffColor.backgroundColor = UIColor(red: 0/255, green: 249/255, blue: 0/255, alpha: 1)
        break
            
        default: lblDiffColor.backgroundColor = UIColor(red: 255/255, green: 169/255, blue: 116/255, alpha: 1)
            
        }
        
        imgLogoImage.image = UIImage(named: "gmu_logo_pic.jpg")
        imgLogoImage.contentMode = .scaleAspectFill
        
        imgTransitImage.image = UIImage(named: randomTransit.TransitImage)
        imgTransitImage.layer.cornerRadius = 15
        imgTransitImage.layer.borderColor = UIColor.darkGray.cgColor
        imgTransitImage.layer.borderWidth = 2
        imgTransitImage.contentMode = .scaleAspectFill
        
        txtTransitDescription.layer.cornerRadius = 15
        txtTransitDescription.layer.borderColor = UIColor.darkGray.cgColor
        txtTransitDescription.layer.borderWidth = 2
        
        scAreaOne.layer.cornerRadius = 15
        scAreaOne.layer.borderColor = UIColor.darkGray.cgColor
        scAreaOne.layer.borderWidth = 2
        
        // Sound Code (Cannot hear the sound output from my computer since I am using MacInTheCloud).
        mySoundFile.play()
        
    }
    
    func InitializeData () {
        let tr1 = TransitRoute()
        tr1.TransitName = "CUE Green 1"
        tr1.TransitDescription = "The CUE Green 1 bus route serves 60 bus stops in the City of Fairfax, departing from George Mason University and ending at the Vienna/Fairfax-GMU Metro Station (Orange Line). The CUE Green 1 bus route serves the eastern half of the City of Fairfax, along with the CUE Green 2 bus route. CUE Green 1 operates in a clockwise direction. Some points of interest include Fairfax Circle, Old Town Square, and Fair City Mall."
        tr1.TransitFrequency = "30-35 mins; Mon-Fri"
        tr1.TransitReliability = "Good"
        tr1.TransitFare = "Free for GMU Students"
        tr1.TransitWeekendService = "Yes; Every hour"
        tr1.TransitFirstDeparture = "5:30 am"
        tr1.TransitLastDeparture = "10:35 pm"
        tr1.TransitWebsite = "https://www.transit.land/routes/r-dqcj1-green1"
        tr1.TransitImage = "green1_bus_pic.jpg"
        TransitRouteArray.append(tr1)
        
        let tr2 = TransitRoute()
        tr2.TransitName = "CUE Green 2"
        tr2.TransitDescription = "The CUE Green 2 bus route serves 57 bus stops in the City of Fairfax, departing from George Mason University and ending at the Vienna/Fairfax-GMU Metro Station (Orange Line). The CUE Green 2 bus route serves the eastern half of the City of Fairfax, along with the CUE Green 1 bus route. CUE Green 2 operates in a counter-clockwise direction. Some points of interest include Old Town Fairfax, Turnpike Shopping Center, and Pickett Shopping Center."
        tr2.TransitFrequency = "30-35 mins; Mon-Fri"
        tr2.TransitReliability = "OK"
        tr2.TransitFare = "Free for GMU Students"
        tr2.TransitWeekendService = "Yes; Every hour"
        tr2.TransitFirstDeparture = "5:15 am"
        tr2.TransitLastDeparture = "8:10 pm"
        tr2.TransitWebsite = "https://www.transit.land/routes/r-dqcj1-green2"
        tr2.TransitImage = "green2_bus_pic.jpg"
        TransitRouteArray.append(tr2)
        
        let tr3 = TransitRoute()
        tr3.TransitName = "CUE Gold 1"
        tr3.TransitDescription = "The CUE Gold 1 bus route serves 65 bus stops in the City of Fairfax, departing from George Mason University and ending at the Vienna/Fairfax-GMU Metro Station (Orange Line). The CUE Gold 1 bus route serves the western half of the City of Fairfax, along with the CUE Gold 2 bus route. CUE Gold 1 operates in a clockwise direction. Some points of interest include Kamp Washington Shopping Center, Fairfax County Judicial Center, and Van Dyck Park."
        tr3.TransitFrequency = "30-35 mins; Mon-Fri"
        tr3.TransitReliability = "Good"
        tr3.TransitFare = "Free for GMU Students"
        tr3.TransitWeekendService = "Yes; Every hour"
        tr3.TransitFirstDeparture = "6:25 am"
        tr3.TransitLastDeparture = "10:37 pm"
        tr3.TransitWebsite = "https://www.transit.land/routes/r-dqcj0-gold1"
        tr3.TransitImage = "gold1_bus_pic.jpg"
        TransitRouteArray.append(tr3)
        
        let tr4 = TransitRoute()
        tr4.TransitName = "CUE Gold 2"
        tr4.TransitDescription = "The CUE Gold 2 bus route serves 63 bus stops in the City of Fairfax, departing from George Mason University and ending at the Vienna/Fairfax-GMU Metro Station (Orange Line). The CUE Gold 2 bus route serves the western half of the City of Fairfax, along with the CUE Gold 1 bus route. CUE Gold 2 operates in a counter-clockwise direction. Some points of interest include the City of Fairfax Regional Library, Kutner Park, and James Swart Shopping Center."
        tr4.TransitFrequency = "30-35 mins; Mon-Fri"
        tr4.TransitReliability = "OK"
        tr4.TransitFare = "Free for GMU Students"
        tr4.TransitWeekendService = "Yes; Every hour"
        tr4.TransitFirstDeparture = "5:37 am"
        tr4.TransitLastDeparture = "9:37 pm"
        tr4.TransitWebsite = "https://www.transit.land/routes/r-dqcj0-gold2"
        tr4.TransitImage = "gold2_bus_pic.jpg"
        TransitRouteArray.append(tr4)
        
        let tr5 = TransitRoute()
        tr5.TransitName = "Metrobus 29K"
        tr5.TransitDescription = "The Metrobus 29K (WMATA) - Alexandria-Fairfax bus route serves 60 bus stops in the Northern Virginia area departing from George Mason University and ending at the King St-Old Town Station (Blue & Yellow Lines). Metrobus 29K serves the City of Alexandria, Fairfax County, and the City of Fairfax. Metrobus 29K runs on Little River Turnpike (Route 236). Some points of interest include Old Town Alexandria, Landmark Mall, and the Town of Annandale."
        tr5.TransitFrequency = "35-40 mins; Mon-Fri"
        tr5.TransitReliability = "Good"
        tr5.TransitFare = "$2.00 fare"
        tr5.TransitWeekendService = "Yes; Every 45 mins"
        tr5.TransitFirstDeparture = "5:29 am"
        tr5.TransitLastDeparture = "10:05 pm"
        tr5.TransitWebsite = "https://www.transit.land/routes/r-dqch-29k"
        tr5.TransitImage = "29k_bus_pic.jpg"
        TransitRouteArray.append(tr5)
        
        let tr6 = TransitRoute()
        tr6.TransitName = "Metrobus 17G"
        tr6.TransitDescription = "The Metrobus 17G (WMATA) - Kings Park Express bus route serves 40 bus stops in the Northern Virginia area departing from George Mason University and ending at the Pentagon Metro Station (Blue & Yellow Lines). Metrobus 17G serves the Pentagon in Arlington, Virginia; Kings Park, Virginia; and Fairfax County. Metrobus 17G primarily runs on Interstate 395 (I-395) (AM & PM Rush Hour Service Only). Metrobus 17G AM destination is the Pentagon, and Metrobus 17G PM destination is Kings Park, VA, (via George Mason University)."
        tr6.TransitFrequency = "15-20 mins; Mon-Fri (Morning & Evening Rush Only)"
        tr6.TransitReliability = "Poor"
        tr6.TransitFare = "$4.25 express fare"
        tr6.TransitWeekendService = "No weekend service"
        tr6.TransitFirstDeparture = "5:59 am (AM rush)"
        tr6.TransitLastDeparture = "7:40 pm (PM rush)"
        tr6.TransitWebsite = "https://www.transit.land/routes/r-dqch-17g"
        tr6.TransitImage = "17g_bus_pic.jpg"
        TransitRouteArray.append(tr6)
        
    }
    
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        imgTransitImage.alpha = 0
        lblTransitFare.alpha = 0
        lblTransitName.alpha = 0
        txtTransitDescription.alpha = 0
        imgLogoImage.alpha = 0
        lblAppTitle.alpha = 0
        scAreaOne.alpha = 0
        lblFrequency.alpha = 0
        lblWeekend.alpha = 0
        lblReliability.alpha = 0
        lblFirstDeparture.alpha = 0
        lblLastDeparture.alpha = 0
        
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        UIView.animate(withDuration: 3, animations: {
            self.imgTransitImage.alpha = 1
            self.lblTransitFare.alpha = 1
            self.lblTransitName.alpha = 1
            self.txtTransitDescription.alpha = 1
            self.imgLogoImage.alpha = 1
            self.lblAppTitle.alpha = 1
            self.scAreaOne.alpha = 1
            self.lblFrequency.alpha = 1
            self.lblWeekend.alpha = 1
            self.lblReliability.alpha = 1
            self.lblFirstDeparture.alpha = 1
            self.lblLastDeparture.alpha = 1
            
        })
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        swFavorite.isOn = false
        InitializeData()
        
        // Sound Code (Cannot hear the sound output from my computer since I am using MacInTheCloud).
        let soundUrl = URL(fileURLWithPath: Bundle.main.path(forResource: "target_hit", ofType: "wav")!)
        mySoundFile = try? AVAudioPlayer(contentsOf: soundUrl)
        
        setLabels()
        // Do any additional setup after loading the view.
        
    }

}
