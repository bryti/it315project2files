//
//  GMUTransit.swift
//  GMUTransit_Project_Fall23_TieuBryan
//
//  DISCLAIMER STATEMENT: "This App is developed as an educational project." If any copyrighted materials are included in accordance to the multimedia fair use guidelines, a notice should be added and states that "certain materials are included under the fair use exemption of the U.S. Copyright Law and have been prepared according to the multimedia fair use guidelines and are restricted from further use".
//
//  Created by Bryan Tieu on 10/10/23.
//
import UIKit
import Foundation
class TransitRoute {
    var TransitName = ""
    var TransitDescription = ""
    var TransitFrequency = ""
    var TransitReliability = ""
    var TransitWeekendService = ""
    var TransitFare = ""
    var TransitImage = ""
    var TransitWebsite = ""
    var TransitFirstDeparture = ""
    var TransitLastDeparture = ""
    
    }
